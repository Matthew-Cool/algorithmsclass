#include <iostream>
#include <graph.hpp>
#include <queue.hpp>
#include <stack.hpp>

void bfs(Graph &G, int start, int destination);
void dfs(Graph &G, int start, int destination); 
void rdfs(Graph &G, int start, int destination); 
